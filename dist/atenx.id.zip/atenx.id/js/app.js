const navToPage = (page_name = null) => {
    window.location.href = page_name + '.html';
};